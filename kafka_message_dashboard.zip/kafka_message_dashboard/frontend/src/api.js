const BASE = '/api';

async function get(path) {
  const res = await fetch(`${BASE}${path}`);
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  return body;
}

export const api = {
  getConfig: () => get('/config'),
  getTopics: () => get('/topics'),
  getConsumerGroups: () => get('/consumer-groups'),
  getPartitions: (topic, groupId) =>
    get(
      `/topics/${encodeURIComponent(topic)}/partitions${
        groupId ? `?groupId=${encodeURIComponent(groupId)}` : ''
      }`
    ),
};
