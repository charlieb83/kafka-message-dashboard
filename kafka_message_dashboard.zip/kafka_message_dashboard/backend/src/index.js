import express from 'express';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { withAdmin, brokerList } from './kafkaClient.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;

function kafkaError(res, context, err) {
  // eslint-disable-next-line no-console
  console.error(`[kafka-dashboard] ${context}:`, err);
  res.status(502).json({
    error: `${context}: ${err.message}. Brokers: ${brokerList.join(', ')}`,
  });
}

app.get('/api/health', (req, res) => {
  res.json({ ok: true, brokers: brokerList });
});

app.get('/api/config', (req, res) => {
  res.json({ brokers: brokerList });
});

app.get('/api/topics', async (req, res) => {
  try {
    const topics = await withAdmin((admin) => admin.listTopics());
    const result = topics
      .map((name) => ({ name, internal: name.startsWith('__') }))
      .sort((a, b) => a.name.localeCompare(b.name));
    res.json(result);
  } catch (err) {
    kafkaError(res, 'Could not list topics', err);
  }
});

app.get('/api/consumer-groups', async (req, res) => {
  try {
    const { groups } = await withAdmin((admin) => admin.listGroups());
    res.json([...groups].sort((a, b) => a.groupId.localeCompare(b.groupId)));
  } catch (err) {
    kafkaError(res, 'Could not list consumer groups', err);
  }
});

app.get('/api/topics/:topic/partitions', async (req, res) => {
  const { topic } = req.params;
  const groupId = typeof req.query.groupId === 'string' ? req.query.groupId : '';

  try {
    const partitions = await withAdmin(async (admin) => {
      const [metadata, offsets] = await Promise.all([
        admin.fetchTopicMetadata({ topics: [topic] }),
        admin.fetchTopicOffsets(topic),
      ]);

      const offsetByPartition = new Map(offsets.map((o) => [o.partition, o]));

      let committedByPartition = new Map();
      if (groupId) {
        const groupOffsets = await admin.fetchOffsets({ groupId, topics: [topic] });
        const topicEntry = groupOffsets.find((t) => t.topic === topic);
        if (topicEntry) {
          committedByPartition = new Map(
            topicEntry.partitions.map((p) => [p.partition, Number(p.offset)])
          );
        }
      }

      const partitionMeta = metadata.topics[0]?.partitions ?? [];

      return partitionMeta
        .map((p) => {
          const o = offsetByPartition.get(p.partitionId);
          const low = o ? Number(o.low) : null;
          const high = o ? Number(o.high) : null;

          let committedOffset = null;
          let lag = null;
          if (groupId && high !== null) {
            const committedRaw = committedByPartition.get(p.partitionId);
            const hasCommitted = committedRaw !== undefined && committedRaw >= 0;
            committedOffset = hasCommitted ? committedRaw : null;
            lag = hasCommitted ? high - committedRaw : high - (low ?? 0);
          }

          return {
            partition: p.partitionId,
            leader: p.leader,
            low,
            high,
            committedOffset,
            lag,
          };
        })
        .sort((a, b) => a.partition - b.partition);
    });

    res.json({ topic, groupId: groupId || null, partitions });
  } catch (err) {
    kafkaError(res, `Failed to load partitions for "${topic}"`, err);
  }
});

// Serve the built React app (copied into ./public by the Docker build).
const staticDir = path.join(__dirname, '..', 'public');
app.use(express.static(staticDir));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  res.sendFile(path.join(staticDir, 'index.html'));
});

app.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`Kafka dashboard backend listening on :${PORT}`);
  // eslint-disable-next-line no-console
  console.log(`Brokers: ${brokerList.join(', ')}`);
});
