import { Kafka, logLevel } from 'kafkajs';

/**
 * Everything about *which* Kafka cluster we talk to lives here, and all of it
 * comes from environment variables. To point this dashboard at a different
 * cluster, change env vars and restart the container — no rebuild needed.
 */
function buildKafkaConfig() {
  const brokers = (process.env.KAFKA_BROKERS || 'localhost:9092')
    .split(',')
    .map((b) => b.trim())
    .filter(Boolean);

  const clientId = process.env.KAFKA_CLIENT_ID || 'kafka-dashboard';

  const config = {
    clientId,
    brokers,
    logLevel: logLevel.NOTHING,
    connectionTimeout: Number(process.env.KAFKA_CONNECTION_TIMEOUT_MS) || 5000,
    retry: {
      initialRetryTime: 300,
      retries: 5,
    },
  };

  if (process.env.KAFKA_SSL === 'true') {
    config.ssl = true;
  }

  // Optional SASL auth, only applied if a mechanism is actually configured.
  // Supports plain / scram-sha-256 / scram-sha-512, enough for most managed
  // Kafka clusters (Confluent Cloud, MSK, etc.) you might point this at later.
  const saslMechanism = process.env.KAFKA_SASL_MECHANISM;
  if (saslMechanism) {
    config.sasl = {
      mechanism: saslMechanism,
      username: process.env.KAFKA_SASL_USERNAME,
      password: process.env.KAFKA_SASL_PASSWORD,
    };
  }

  return { config, brokers };
}

const { config, brokers } = buildKafkaConfig();
export const brokerList = brokers;

const kafka = new Kafka(config);
export const admin = kafka.admin();

let connected = false;
let connectPromise = null;

async function ensureConnected() {
  if (connected) return;
  if (!connectPromise) {
    connectPromise = admin
      .connect()
      .then(() => {
        connected = true;
      })
      .finally(() => {
        connectPromise = null;
      });
  }
  return connectPromise;
}

/**
 * Runs `fn` against a connected admin client, reconnecting first if needed.
 * If the call fails in a way that looks connection-related, we mark the
 * client as disconnected so the *next* call retries the handshake instead
 * of repeatedly failing against a stale connection.
 */
export async function withAdmin(fn) {
  await ensureConnected();
  try {
    return await fn(admin);
  } catch (err) {
    if (/connect|ECONNREFUSED|ENOTFOUND|disconnect|timeout/i.test(err?.message || '')) {
      connected = false;
    }
    throw err;
  }
}
