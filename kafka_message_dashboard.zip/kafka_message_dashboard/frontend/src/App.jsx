import { useEffect, useMemo, useRef, useState } from 'react';
import { api } from './api.js';
import Header from './components/Header.jsx';
import Controls from './components/Controls.jsx';
import StatTiles from './components/StatTiles.jsx';
import PartitionTable from './components/PartitionTable.jsx';

const REFRESH_MS = 5000;
const LIST_REFRESH_MS = 30000;

export default function App() {
  const [brokers, setBrokers] = useState([]);
  const [topics, setTopics] = useState([]);
  const [groups, setGroups] = useState([]);
  const [showInternal, setShowInternal] = useState(false);
  const [selectedTopic, setSelectedTopic] = useState('');
  const [selectedGroup, setSelectedGroup] = useState('');
  const [partitions, setPartitions] = useState([]);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [listError, setListError] = useState(null);

  const pollRef = useRef(null);

  // Load the topic/consumer-group lists on mount and keep them fresh —
  // topics and groups can appear or disappear while the dashboard is open.
  useEffect(() => {
    let cancelled = false;

    async function loadLists() {
      try {
        const [config, topicList, groupList] = await Promise.all([
          api.getConfig(),
          api.getTopics(),
          api.getConsumerGroups(),
        ]);
        if (cancelled) return;
        setBrokers(config.brokers);
        setTopics(topicList);
        setGroups(groupList);
        setListError(null);
      } catch (err) {
        if (!cancelled) setListError(err.message);
      }
    }

    loadLists();
    const id = setInterval(loadLists, LIST_REFRESH_MS);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  const visibleTopics = useMemo(
    () => topics.filter((t) => showInternal || !t.internal),
    [topics, showInternal]
  );

  async function loadPartitions() {
    if (!selectedTopic) return;
    setLoading(true);
    try {
      const data = await api.getPartitions(selectedTopic, selectedGroup);
      setPartitions(data.partitions);
      setLastUpdated(new Date());
      setError(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  // Reload immediately whenever the topic or group selection changes.
  useEffect(() => {
    setPartitions([]);
    setError(null);
    if (selectedTopic) loadPartitions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedTopic, selectedGroup]);

  // Poll on an interval while auto-refresh is on and a topic is selected.
  useEffect(() => {
    clearInterval(pollRef.current);
    if (autoRefresh && selectedTopic) {
      pollRef.current = setInterval(loadPartitions, REFRESH_MS);
    }
    return () => clearInterval(pollRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoRefresh, selectedTopic, selectedGroup]);

  const groupSelected = Boolean(selectedGroup);

  return (
    <div className="app">
      <Header brokers={brokers} listError={listError} />
      <main>
        <Controls
          topics={visibleTopics}
          groups={groups}
          selectedTopic={selectedTopic}
          selectedGroup={selectedGroup}
          showInternal={showInternal}
          autoRefresh={autoRefresh}
          loading={loading}
          lastUpdated={lastUpdated}
          onTopicChange={setSelectedTopic}
          onGroupChange={setSelectedGroup}
          onShowInternalChange={setShowInternal}
          onAutoRefreshChange={setAutoRefresh}
          onRefreshNow={loadPartitions}
        />

        {error && <div className="banner banner--error">{error}</div>}

        {selectedTopic ? (
          <>
            <StatTiles partitions={partitions} groupSelected={groupSelected} />
            <PartitionTable partitions={partitions} groupSelected={groupSelected} />
            {!groupSelected && (
              <p className="muted hint">
                Pick a consumer group above to see committed offsets and lag for
                it. Without a group this just shows each partition's current
                offset range.
              </p>
            )}
          </>
        ) : (
          <div className="empty-state">Pick a topic above to see its partitions.</div>
        )}
      </main>
    </div>
  );
}
