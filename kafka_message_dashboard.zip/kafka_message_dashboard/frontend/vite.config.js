import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// In production the backend serves the built app and the API from the same
// origin, so the frontend just calls "/api/...". In local dev (`npm run dev`
// inside frontend/), we proxy /api to the backend dev server so there's no
// CORS dance either way.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: process.env.VITE_API_PROXY_TARGET || 'http://localhost:4000',
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: 'dist',
  },
});
