# Kafka Dashboard

A small, self-contained dashboard for inspecting a Kafka cluster: pick a
topic, optionally pick a consumer group, see every partition's low/high
watermark, the group's committed offset, and lag.

It runs as its own Docker container, completely independent of the Kafka
cluster it's pointed at. To monitor a different cluster later, you change
one environment variable (`KAFKA_BROKERS`) and restart the container — no
rebuild, no code changes.

## How it works

- **Backend** (`backend/`): a small Express API using `kafkajs`'s Admin
  client to talk to Kafka directly over the wire protocol (browsers can't do
  this themselves — Kafka isn't HTTP). It exposes:
  - `GET /api/topics` — all topic names
  - `GET /api/consumer-groups` — all consumer group IDs
  - `GET /api/topics/:topic/partitions?groupId=...` — per-partition low/high
    watermark, and (if a group is given) committed offset + lag
- **Frontend** (`frontend/`): a React app (Vite) that calls the API above
  and renders the topic/group pickers, stat tiles, and the partition table.
- **Docker**: a single multi-stage `Dockerfile` builds the React app and
  bakes it into the same image as the backend, which serves both the static
  UI and the `/api/*` routes. One container, one port.

### Why a consumer group is optional

"Lag" only means something relative to *something that's reading the
topic* — it's `high watermark - last committed offset` for a given consumer
group. Without a group selected, the dashboard still shows you each
partition's current offset range (its "pointers"), just not lag, since
there's nothing to measure lag against yet. Pick a group from the second
dropdown to see committed offsets and lag.

## Run it

```bash
docker compose up --build
```

Then open http://localhost:3000.

By default `docker-compose.yml` sets `KAFKA_BROKERS=host.docker.internal:9092`,
which reaches a Kafka broker published on your host machine's port 9092 (the
common case when your Kafka container does `ports: ["9092:9092"]`). Override
it by copying `.env.example` to `.env` and editing it, or inline:

```bash
KAFKA_BROKERS=host.docker.internal:9092 docker compose up --build
```

### Pointing at other Kafka instances later

Just change `KAFKA_BROKERS` — no rebuild needed, the backend reads it at
startup. Depending on where the target broker lives relative to this
container, use one of:

| Target broker location | `KAFKA_BROKERS` value |
|---|---|
| Published on your host machine (e.g. `docker run -p 9092:9092 ...`) | `host.docker.internal:9092` |
| A container on the same Docker network (e.g. a `kafka` service in another compose file) | `kafka:9092` — join that network via `docker-compose.yml`'s `networks:` key, and make sure the broker's `advertised.listeners` actually resolves that way |
| A remote/managed cluster (Confluent Cloud, MSK, etc.) | the real `host:port` list, likely with `KAFKA_SSL=true` and `KAFKA_SASL_*` set |

Multiple brokers: comma-separate them, e.g. `broker1:9092,broker2:9092`.

### Auth / TLS

If the target cluster needs it, set (uncomment in `docker-compose.yml`):

- `KAFKA_SSL=true`
- `KAFKA_SASL_MECHANISM` — `plain`, `scram-sha-256`, or `scram-sha-512`
- `KAFKA_SASL_USERNAME` / `KAFKA_SASL_PASSWORD`

This covers password-based SASL. For Kerberos/GSSAPI (e.g. a Cloudera
cluster with a keytab), see the next section — it needs a different Kafka
client library and isn't implemented yet.

### Kerberized clusters (Cloudera, etc.) — planned, not yet implemented

The backend currently uses `kafkajs`, a pure-JS client. `kafkajs` has **no
built-in Kerberos/GSSAPI support** — this isn't a config gap, the mechanism
just isn't implemented in the library. So pointing this dashboard at a
Kerberized cluster (Cloudera, Hortonworks, most on-prem enterprise Kafka)
needs a library swap, not just new env vars.

**Planned approach:** swap the backend's Kafka client from `kafkajs` to
[`node-rdkafka`](https://github.com/Blizzard/node-rdkafka), which wraps
`librdkafka` (the same C library behind the Java/Python/C clients) and has
mature GSSAPI support via flat config properties — note this is *not* a
Java-style `jaas.conf` file, librdkafka just takes properties directly:

```
security.protocol=SASL_SSL        # or SASL_PLAINTEXT
sasl.mechanisms=GSSAPI
sasl.kerberos.keytab=/path/to/keytab
sasl.kerberos.principal=yourservice@YOUR.REALM
sasl.kerberos.service.name=kafka   # the broker's principal prefix, e.g. kafka/_HOST@REALM
```

What that implies for this project, when we come back to it:

- **Dockerfile**: needs Kerberos system packages (`krb5-user`,
  `libsasl2-modules-gssapi-mit`) plus native build tooling, since
  `node-rdkafka` compiles against `librdkafka` on install. Heavier image
  than the current pure-JS one.
- **Keytab handling**: the keytab is a credential — it must be mounted into
  the container at runtime (a Docker volume / secret), never baked into the
  image or committed to the repo.
- **TLS**: if the cluster also uses TLS (common with Cloudera Manager
  auto-TLS, i.e. `SASL_SSL`), its CA cert needs to be mounted in too.
- **Still env-var-driven**: broker list, keytab path, principal, and service
  name would all stay env vars, so switching between a local Kafka and a
  Kerberized Cloudera cluster is still just config, not code.

Still need from whoever picks this up: SASL_SSL vs SASL_PLAINTEXT, the
keytab + principal for a service account, the broker's service principal
name (usually `kafka/_HOST@REALM`), and whether a `krb5.conf` already exists
elsewhere to mirror.

## Local development (without Docker)

```bash
# terminal 1 — API on :4000
cd backend
npm install
KAFKA_BROKERS=localhost:9092 npm run dev

# terminal 2 — UI on :5173, proxies /api to :4000
cd frontend
npm install
npm run dev
```

## Notes

- Internal topics (`__consumer_offsets`, `__transaction_state`, …) are
  hidden by default; toggle "Show internal topics" to see them.
- The table auto-refreshes every 5s while a topic is selected; toggle it off
  or click "Refresh now" for a manual pull.
- The partition list refreshes every 30s in the background so new
  topics/groups show up without a page reload.
