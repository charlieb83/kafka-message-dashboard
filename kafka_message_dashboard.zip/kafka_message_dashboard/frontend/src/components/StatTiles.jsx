function sum(nums) {
  return nums.reduce((a, b) => a + b, 0);
}

export default function StatTiles({ partitions, groupSelected }) {
  const lags = partitions.map((p) => p.lag).filter((v) => v !== null && v !== undefined);
  const totalLag = lags.length ? sum(lags) : 0;
  const maxLag = lags.length ? Math.max(...lags) : 0;
  const inSync = lags.filter((l) => l === 0).length;

  const tiles = [
    { label: 'Partitions', value: partitions.length.toLocaleString() },
    {
      label: 'Total lag',
      value: groupSelected ? totalLag.toLocaleString() : '—',
      hint: groupSelected ? null : 'Select a consumer group',
    },
    {
      label: 'Max partition lag',
      value: groupSelected ? maxLag.toLocaleString() : '—',
    },
    {
      label: 'Partitions in sync',
      value: groupSelected && lags.length ? `${inSync}/${lags.length}` : '—',
    },
  ];

  return (
    <section className="stat-tiles">
      {tiles.map((t) => (
        <div className="stat-tile" key={t.label}>
          <div className="stat-tile__value">{t.value}</div>
          <div className="stat-tile__label">{t.label}</div>
          {t.hint && <div className="stat-tile__hint">{t.hint}</div>}
        </div>
      ))}
    </section>
  );
}
