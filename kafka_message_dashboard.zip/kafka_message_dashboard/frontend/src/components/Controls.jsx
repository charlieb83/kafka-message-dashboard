export default function Controls({
  topics,
  groups,
  selectedTopic,
  selectedGroup,
  showInternal,
  autoRefresh,
  loading,
  lastUpdated,
  onTopicChange,
  onGroupChange,
  onShowInternalChange,
  onAutoRefreshChange,
  onRefreshNow,
}) {
  return (
    <section className="controls">
      <label className="field">
        <span>Topic</span>
        <select value={selectedTopic} onChange={(e) => onTopicChange(e.target.value)}>
          <option value="">Select a topic…</option>
          {topics.map((t) => (
            <option key={t.name} value={t.name}>
              {t.name}
              {t.internal ? ' (internal)' : ''}
            </option>
          ))}
        </select>
      </label>

      <label className="field">
        <span>Consumer group</span>
        <select value={selectedGroup} onChange={(e) => onGroupChange(e.target.value)}>
          <option value="">None — offsets only</option>
          {groups.map((g) => (
            <option key={g.groupId} value={g.groupId}>
              {g.groupId}
            </option>
          ))}
        </select>
      </label>

      <label className="field field--checkbox">
        <input
          type="checkbox"
          checked={showInternal}
          onChange={(e) => onShowInternalChange(e.target.checked)}
        />
        <span>Show internal topics</span>
      </label>

      <label className="field field--checkbox">
        <input
          type="checkbox"
          checked={autoRefresh}
          onChange={(e) => onAutoRefreshChange(e.target.checked)}
        />
        <span>Auto-refresh (5s)</span>
      </label>

      <button
        type="button"
        className="btn"
        onClick={onRefreshNow}
        disabled={!selectedTopic || loading}
      >
        {loading ? 'Refreshing…' : 'Refresh now'}
      </button>

      {lastUpdated && (
        <span className="muted last-updated">Updated {lastUpdated.toLocaleTimeString()}</span>
      )}
    </section>
  );
}
