export default function Header({ brokers, listError }) {
  return (
    <header className="app-header">
      <div className="app-header__title">
        <h1>Kafka Dashboard</h1>
        <span className="muted">
          Connected to {brokers.length ? brokers.join(', ') : '…'}
        </span>
      </div>
      {listError && <div className="banner banner--error">{listError}</div>}
    </header>
  );
}
