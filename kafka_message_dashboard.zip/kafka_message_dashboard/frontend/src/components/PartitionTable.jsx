function format(n) {
  return n === null || n === undefined ? '—' : n.toLocaleString();
}

function LagBar({ value, max }) {
  if (value === null || value === undefined) return <span className="muted">—</span>;
  if (value === 0) return <span className="lag-ok">0 · in sync</span>;

  const ratio = value / max;
  const pct = Math.max(4, Math.min(100, Math.round(ratio * 100)));
  const status = ratio > 0.66 ? 'critical' : ratio > 0.33 ? 'warning' : 'default';

  return (
    <div className="lag-bar" title={`${value.toLocaleString()} records behind`}>
      <span className="lag-bar__value">{value.toLocaleString()}</span>
      <span className="lag-bar__track">
        <span
          className={`lag-bar__fill lag-bar__fill--${status}`}
          style={{ width: `${pct}%` }}
        />
      </span>
    </div>
  );
}

export default function PartitionTable({ partitions, groupSelected }) {
  if (!partitions.length) {
    return <div className="empty-state">Loading partitions…</div>;
  }

  const maxLag = Math.max(1, ...partitions.map((p) => p.lag || 0));

  return (
    <div className="table-wrap">
      <table className="partition-table">
        <thead>
          <tr>
            <th>Partition</th>
            <th>Low watermark</th>
            <th>High watermark</th>
            <th>Committed offset</th>
            <th>Lag</th>
          </tr>
        </thead>
        <tbody>
          {partitions.map((p) => (
            <tr key={p.partition}>
              <td>{p.partition}</td>
              <td className="num">{format(p.low)}</td>
              <td className="num">{format(p.high)}</td>
              <td className="num">{groupSelected ? format(p.committedOffset) : '—'}</td>
              <td className="num lag-cell">
                {groupSelected ? <LagBar value={p.lag} max={maxLag} /> : <span className="muted">—</span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
